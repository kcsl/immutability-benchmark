public class SimpleCell<T extends /*readonly*/ Object> {

    T val;

}
