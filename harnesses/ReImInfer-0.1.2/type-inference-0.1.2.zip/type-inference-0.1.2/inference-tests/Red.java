
public class Red {
  private int i;
  
  public Red(int in) {
    i = in;
  }
  
  public void set(int in) {
    i = in;
  }
  
  public int get() {
    return i;
  }
}
