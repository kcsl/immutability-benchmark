package java.lang;
import checkers.inference.reim.quals.*;

public interface Cloneable {}
