package java.lang;
import checkers.inference.reim.quals.*;

public class ClassCastException extends RuntimeException {
    private static final long serialVersionUID = -9223365651070458532L;

    public ClassCastException() {
        throw new RuntimeException("skeleton method");
    }

    public ClassCastException(String s) {
        throw new RuntimeException("skeleton method");
    }
}
