package java.lang.reflect;
import checkers.inference.reim.quals.*;

public @Readonly interface Type {}
