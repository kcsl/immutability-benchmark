package java.io;
import checkers.inference.reim.quals.*;

public interface Serializable {}
