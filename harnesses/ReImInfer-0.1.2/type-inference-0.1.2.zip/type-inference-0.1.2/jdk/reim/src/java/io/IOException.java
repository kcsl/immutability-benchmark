package java.io;
import checkers.inference.reim.quals.*;

public class IOException extends Exception {
    static final long serialVersionUID = 7818375828146090155L;

    public IOException() {
        throw new RuntimeException("skeleton method");
    }

    public IOException(String message) {
        throw new RuntimeException("skeleton method");
    }

    public IOException(String message, Throwable cause) {
        throw new RuntimeException("skeleton method");
    }

    public IOException(Throwable cause) {
        throw new RuntimeException("skeleton method");
    }
}
