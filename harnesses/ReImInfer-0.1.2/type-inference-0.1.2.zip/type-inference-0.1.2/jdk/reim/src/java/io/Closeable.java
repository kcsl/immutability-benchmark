package java.io;
import checkers.inference.reim.quals.*;

public interface Closeable {

    public void close() throws IOException;

}
