package java.io;
import checkers.inference.reim.quals.*;

public class FileWriter extends OutputStreamWriter {
    public FileWriter(String fileName) throws IOException {
        throw new RuntimeException("skeleton method");
    }

    public FileWriter(String fileName, boolean append) throws IOException {
        throw new RuntimeException("skeleton method");
    }

    public FileWriter(File file) throws IOException {
        throw new RuntimeException("skeleton method");
    }

    public FileWriter(File file, boolean append) throws IOException {
        throw new RuntimeException("skeleton method");
    }

    public FileWriter(FileDescriptor fd) {
        throw new RuntimeException("skeleton method");
    }
}
