package java.util;
import checkers.inference.reim.quals.*;

public interface RandomAccess {}
