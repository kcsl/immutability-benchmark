package java.util;
import checkers.inference.reim.quals.*;

public class StringTokenizer implements Enumeration<Object> {
  public StringTokenizer(String a1, String a2, boolean a3) { throw new RuntimeException(("skeleton method")); }
  public StringTokenizer(String a1, String a2) { throw new RuntimeException(("skeleton method")); }
  public StringTokenizer(String a1) { throw new RuntimeException(("skeleton method")); }
  public boolean hasMoreTokens(@Readonly StringTokenizer this)  { throw new RuntimeException(("skeleton method")); }
  public @Polyread String nextToken(@Polyread StringTokenizer this)  { throw new RuntimeException(("skeleton method")); }
  public @Polyread String nextToken(@Polyread StringTokenizer this, String a1)  { throw new RuntimeException(("skeleton method")); }
  public boolean hasMoreElements(@Readonly StringTokenizer this)  { throw new RuntimeException(("skeleton method")); }
  public @Polyread Object nextElement(@Polyread StringTokenizer this)  { throw new RuntimeException(("skeleton method")); }
  public int countTokens(@Readonly StringTokenizer this)  { throw new RuntimeException(("skeleton method")); }
}
