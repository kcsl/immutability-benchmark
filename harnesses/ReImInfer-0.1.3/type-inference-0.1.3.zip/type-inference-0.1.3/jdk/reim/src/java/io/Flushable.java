package java.io;
import checkers.inference.reim.quals.*;

public interface Flushable {

    void flush() throws IOException;
}
