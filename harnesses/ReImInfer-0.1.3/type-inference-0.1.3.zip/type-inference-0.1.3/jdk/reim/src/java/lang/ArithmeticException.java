package java.lang;
import checkers.inference.reim.quals.*;

public class ArithmeticException extends RuntimeException {
    private static final long serialVersionUID = 2256477558314496007L;

    public ArithmeticException() {
        throw new RuntimeException("skeleton method");
    }

    public ArithmeticException(String s) {
        throw new RuntimeException("skeleton method");
    }
}
