package java.io;
import checkers.inference.reim.quals.*;

public class FileNotFoundException extends IOException {
    private static final long serialVersionUID = -897856973823710492L;

    public FileNotFoundException() {
        throw new RuntimeException("skeleton method");
    }

    public FileNotFoundException(String s) {
        throw new RuntimeException("skeleton method");
    }
}
