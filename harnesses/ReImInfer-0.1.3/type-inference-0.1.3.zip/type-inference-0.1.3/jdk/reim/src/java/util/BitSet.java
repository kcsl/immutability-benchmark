package java.util;
import checkers.inference.reim.quals.*;

public class BitSet implements Cloneable, java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public BitSet() { throw new RuntimeException(("skeleton method")); }
  public BitSet(int a1) { throw new RuntimeException(("skeleton method")); }
  public void flip(int a1) { throw new RuntimeException(("skeleton method")); }
  public void flip(int a1, int a2) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1, boolean a2) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1, int a2) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1, int a2, boolean a3) { throw new RuntimeException(("skeleton method")); }
  public void clear(int a1) { throw new RuntimeException(("skeleton method")); }
  public void clear(int a1, int a2) { throw new RuntimeException(("skeleton method")); }
  public void clear() { throw new RuntimeException(("skeleton method")); }
  public boolean get(@Readonly BitSet this, int a1)  { throw new RuntimeException(("skeleton method")); }
  public BitSet get(@Readonly BitSet this, int a1, int a2)  { throw new RuntimeException(("skeleton method")); }
  public int nextSetBit(@Readonly BitSet this, int a1)  { throw new RuntimeException(("skeleton method")); }
  public int nextClearBit(@Readonly BitSet this, int a1)  { throw new RuntimeException(("skeleton method")); }
  public int length(@Readonly BitSet this)  { throw new RuntimeException(("skeleton method")); }
  public boolean isEmpty(@Readonly BitSet this)  { throw new RuntimeException(("skeleton method")); }
  public boolean intersects(@Readonly BitSet this, BitSet a1)  { throw new RuntimeException(("skeleton method")); }
  public int cardinality(@Readonly BitSet this)  { throw new RuntimeException(("skeleton method")); }
  public void and(@Readonly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public void or(@Readonly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public void xor(@Readonly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public void andNot(@Readonly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public int hashCode(@Readonly BitSet this) { throw new RuntimeException(("skeleton method")); }
  public int size(@Readonly BitSet this)  { throw new RuntimeException(("skeleton method")); }
  public boolean equals(@Readonly BitSet this, @Readonly Object a1)  { throw new RuntimeException(("skeleton method")); }
  public Object clone(@Readonly BitSet this)  { throw new RuntimeException(("skeleton method")); }
  public String toString(@Readonly BitSet this) { throw new RuntimeException(("skeleton method")); }
}
