package java.net;
import checkers.inference.reim.quals.*;

import java.io.IOException;

public class MalformedURLException extends IOException {
    private static final long serialVersionUID = -182787522200415866L;

    public MalformedURLException() {
        throw new RuntimeException("skeleton method");
    }

    public MalformedURLException(String msg) {
        throw new RuntimeException("skeleton method");
    }
}
