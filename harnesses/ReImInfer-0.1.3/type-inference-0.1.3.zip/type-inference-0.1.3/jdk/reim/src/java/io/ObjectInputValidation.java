package java.io;

import checkers.inference.reim.quals.*;

public interface ObjectInputValidation {
    public void validateObject() throws InvalidObjectException;
}
