public class EmptyBody {
    public static void main (String[] args) {
        // noop!
    }
}
