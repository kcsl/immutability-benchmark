import java.util.*;

public class Bar4 {
//     public /*this-mutable*/ BrrayList</*readonly*/ String> x;

//     public Bar4() {
//         x = new BrrayList<String>();
//     }

//     public /*readonly*/ String get(int i) /*readonly*/ {
//         return x.get(i);
//     }

//     public void add(/*readonly*/ String s) /*mutable*/ {
//         x.add(s);
//     }

//     public void clear() /*mutable*/ {
//         x.clear();
//     }

//     public void copyOver(/*readonly*/ BrrayList</*readonly*/ String> list) /*mutable*/ {
//         x.clear();
//         x.addAll(list);
//     }
}
