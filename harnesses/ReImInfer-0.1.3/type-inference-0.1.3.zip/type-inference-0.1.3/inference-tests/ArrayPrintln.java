public class ArrayPrintln {

  public static void main1(String[] args) {
  }

  public static void main2(String[] args) {
    args.toString();
  }

  public static void main3(String[] args) {
    System.out.println(args);
  }
  
  public static void main4(String[] args) {
    System.out.println(args.toString());
  }
  
}
